# study_general
study material regarding general topics
